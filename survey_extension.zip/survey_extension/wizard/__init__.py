# -*- coding: utf-8 -*-
"""Carga de asistentes (wizards) para survey_extension."""

from . import survey_version_wizard
from . import survey_code_selection_wizard
from . import survey_edit_question_title_wizard
from . import survey_assign_device_wizard
